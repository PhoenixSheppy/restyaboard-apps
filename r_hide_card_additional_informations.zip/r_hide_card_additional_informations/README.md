### Hide Card Additional Informations

- Hide Card Additional Informations from cards listing
- Disable it in Admin Control Panel for default behavior.
